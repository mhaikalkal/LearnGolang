This translator API is CLI based
to run this code simply type :

go run translator.go -sourceLang="<fill>" -targetLang="<fill>" -sentence="<fill>"

-sourceLang == language you want to translate from
-targetLang == language you want to translate to
-sentence == sentences you want to translate